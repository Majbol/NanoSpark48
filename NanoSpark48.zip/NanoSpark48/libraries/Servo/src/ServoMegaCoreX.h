// Dummy file to deal with issue https://github.com/MCUdude/MegaCoreX/issues/167

#include <Servo.h>
